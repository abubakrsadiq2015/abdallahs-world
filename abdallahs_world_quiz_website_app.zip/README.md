# Abdallah's World — free kids quiz website/app

This is a free, installable PWA (Progressive Web App). It works as a website and can be installed on a phone or computer from a supported browser.

## Included
- Quran quiz
- Tajweed quiz
- Science quiz
- Robotics quiz
- ₦2,000 competition prize information
- No entry fee
- Mobile-friendly design
- Install App button
- Works offline after the first load

## Important
This starter version does NOT collect children's names, phone numbers, photos, or payment details. A guardian/admin should run the competition, verify the winner, publish the competition date/closing time, and arrange the ₦2,000 prize.

## Free publishing
The easiest free option is GitHub Pages:
1. Create a GitHub account with a guardian.
2. Create a public repository, for example `abdallahs-world`.
3. Upload all files in this folder.
4. In the repository, open Settings → Pages.
5. Select the main branch and root folder, then save.
6. GitHub will give you the free website address.

For a real competition, add a secure server/admin system before using online leaderboards or collecting any child information.
