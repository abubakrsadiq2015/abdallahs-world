const quizzes={
quran:{title:"Quran Quiz",icon:"📖",qs:[
["What is the Quran?","The holy book of Islam",["A science textbook","The holy book of Islam","A history of Nigeria","A map"]],
["Who received the Quran through Angel Jibril (Gabriel)?","Prophet Muhammad",["Prophet Musa","Prophet Nuh","Prophet Muhammad","Prophet Ibrahim"]],
["What is a surah?","A chapter of the Quran",["A chapter of the Quran","A type of prayer mat","A language","A mosque"]]
]},
tajweed:{title:"Tajweed Quiz",icon:"🕌",qs:[
["What is Tajweed mainly about?","Correct pronunciation and recitation of the Quran",["Drawing Arabic letters","Correct pronunciation and recitation of the Quran","Learning football rules","Building robots"]],
["Why is Tajweed useful?","It helps a reader recite Quran correctly",["It changes the meaning on purpose","It helps a reader recite Quran correctly","It teaches coding only","It replaces memorisation"]],
["Which language are the Quran's original words in?","Arabic",["English","Arabic","Hausa","French"]]
]},
science:{title:"Science Quiz",icon:"🔬",qs:[
["Which planet is known as the Red Planet?","Mars",["Earth","Mars","Jupiter","Venus"]],
["What do plants use sunlight for?","Photosynthesis",["Photosynthesis","Magnetism","Sound waves","Rusting"]],
["What force pulls objects toward Earth?","Gravity",["Gravity","Friction only","Electricity","Wind"]]
]},
robotics:{title:"Robotics Quiz",icon:"🤖",qs:[
["What is a robot?","A machine that can perform programmed tasks",["A type of plant","A machine that can perform programmed tasks","A planet","A musical instrument"]],
["What does a sensor help a robot do?","Detect information about its environment",["Eat food","Detect information about its environment","Sleep","Grow leaves"]],
["What is an actuator used for?","Creating movement or physical action",["Creating movement or physical action","Writing a story","Measuring rainfall only","Storing water"]]
]}
};

let subject,idx=0,score=0,selected=false;
const quiz=document.querySelector("#quiz"), q=document.querySelector("#question"), answers=document.querySelector("#answers");
const next=document.querySelector("#nextBtn"), title=document.querySelector("#subjectTitle"), icon=document.querySelector("#subjectIcon"), progress=document.querySelector("#progress");

document.querySelectorAll(".card").forEach(btn=>btn.addEventListener("click",()=>start(btn.dataset.subject)));
function start(s){subject=quizzes[s];idx=0;score=0;quiz.hidden=false;quiz.scrollIntoView({behavior:"smooth",block:"start"});render();}
function render(){
 selected=false;next.disabled=true;
 const item=subject.qs[idx];
 icon.textContent=subject.icon;title.textContent=subject.title;progress.textContent=`${idx+1}/${subject.qs.length}`;
 q.textContent=item[0];answers.innerHTML="";
 item[2].forEach(a=>{const b=document.createElement("button");b.className="answer";b.textContent=a;b.onclick=()=>choose(b,a,item[1]);answers.appendChild(b)});
}
function choose(btn,a,correct){
 if(selected)return;selected=true;next.disabled=false;
 document.querySelectorAll(".answer").forEach(b=>{if(b.textContent===correct)b.classList.add("correct")});
 if(a===correct){btn.classList.add("correct");score++}else btn.classList.add("wrong");
}
next.onclick=()=>{idx++; if(idx<subject.qs.length)render();else finish()};
function finish(){
 q.textContent=`You scored ${score} out of ${subject.qs.length}!`;
 answers.innerHTML="";
 const p=document.createElement("p");p.innerHTML=score===subject.qs.length?"🌟 Perfect score!":"👏 Great job — keep learning!";
 answers.appendChild(p);next.textContent="Choose another quiz";next.onclick=()=>quiz.hidden=true;
}
if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js");
let deferredPrompt; const installBtn=document.querySelector("#installBtn");
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;installBtn.hidden=false});
installBtn.onclick=async()=>{if(deferredPrompt){deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;installBtn.hidden=true}};
